const form = document.querySelector(".top-banner form");
const input = document.querySelector(".top-banner input");
const msg = document.querySelector(".top-banner .msg");
const list = document.querySelector(".ajax-section .cities");
/*SUBSCRIBE HERE FOR API KEY: https://home.openweathermap.org/users/sign_up*/
const apiKey = "4d8fb5b93d4af21d66a2948710284366";

form.addEventListener("submit", e => {
    e.preventDefault();
    let inputVal = input.value;
    const listItems = list.querySelectorAll(".ajax-section .city");
    const listItemsArray = Array.from(listItems);

    if (listItemsArray.length > 0) {
        const filteredArray = listItemsArray.filter(el => {
            let content = "";
            if (inputVal.includes(",")) {
                if (inputVal.split(",")[1].length > 2) {
                    inputVal = inputVal.split(",")[0];
                    content = el
                        .querySelector(".city-name span")
                        .textContent.toLowerCase();
                } else {
                    content = el.querySelector(".city-name").dataset.name.toLowerCase();
                }
            } else {
                content = el.querySelector(".city-name span").textContent.toLowerCase();
            }
            return content == inputVal.toLowerCase();
        });

        if (filteredArray.length > 0) {
            msg.textContent = `You already know the weather for ${
                filteredArray[0].querySelector(".city-name span").textContent
            } ...otherwise be more specific by providing the country code as well`;
            form.reset();
            input.focus();
            return;
        }
    }
    const url = `https://api.openweathermap.org/data/2.5/weather?q=${inputVal}&appid=${apiKey}&units=metric`;

    fetch(url)
        .then(response => response.json())
        .then(data => {
            const {
                main,
                name,
                wind,
                sys,
                weather
            } = data;
            const icon = `https://s3-us-west-2.amazonaws.com/s.cdpn.io/162656/${
                    weather[0]["icon"]
            }.svg`;
            const li = document.createElement("li");
            li.classList.add("city");
            const markup = `
                    <h2 class="city-name" data-name="${name},${wind.speed},${sys.country}">
                    <div class="country_heading">
                        <span>${name}</span>
                        <sup>${sys.country}</sup>
                    </div>
                    <div class="city-temp celious_txt">${Math.round(main.temp)}°C</div>
                    <figure>
                        <img class="city-icon" src="${icon}" alt="${
                                weather[0]["description"]
                            }">
                        <figcaption>${weather[0]["description"]}</figcaption>
                    </figure>
                    <div class="font_size">Wind Speed: <span>${wind.speed}</span></div>
                    <div class="font_size">Temp Min: <span>${main.temp_min}</span></div>
                    <div class="font_size">Temp Max: <span>${main.temp_max}</span></div>
                    <div class="font_size">Humidity: <span>${main.humidity}</span></div>
                    <div class="font_size">Pressure: <span>${main.pressure}</span></div>
                    <div class="font_size">sunrise: <span>${sys.sunrise}</span></div>
                    <div class="font_size">sunset: <span>${sys.sunset}</span></div>
                    </h2>
                `;
            li.innerHTML = markup;
            list.appendChild(li);
        })
        .catch(() => {
            msg.textContent = "Please search for a valid city";
        });
    msg.textContent = "";
    form.reset();
    input.focus();
});